#! /sbin/nft -f

delete rule nat miniupnpd
delete rule nat miniupnpd-pcp-peer
delete rule filter miniupnpd
