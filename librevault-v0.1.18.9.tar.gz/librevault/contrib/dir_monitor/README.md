dir_monitor
===========

Filesystem changes monitor using boost::asio © Boris Schaeling

Fixes and extensions contributed by @pmed, @obaskanderi, @GamePad64 and @sbelsky from GitHub.

[![Build Status](https://travis-ci.org/berkus/dir_monitor.svg?branch=master)](https://travis-ci.org/berkus/dir_monitor)

Please create PRs against `develop` branch. `master` branch is used for stable releases only.
