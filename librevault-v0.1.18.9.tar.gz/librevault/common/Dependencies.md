LVCommon Dependencies
=====================

Third-party libraries
---------------------
- Boost - Boost Software License
- Crypto++ - Boost Software License
- Protocol Buffers - New BSD License

CMake Modules
-------------
- FindCryptoPP - MIT